# Word Meaning Dictionary App

This is a simple Python-based Dictionary App with a GUI interface using Tkinter. 
It allows users to search for word meanings and add new words to the dictionary.

## 📁 Files Included
- dictionary_app.py: The main Python script that runs the application.
- dictionary.txt: Text file containing word-meaning pairs (10 entries provided).
- README.txt: Instructions on how to run and use the app.

## 🚀 How to Run the App

### Step 1: Requirements
- Python 3.x installed on your system.
- Tkinter (comes pre-installed with Python).

### Step 2: Running the App
1. Open the folder `DictionaryApp`.
2. Run the `dictionary_app.py` file:
   - Option A: Double-click it (if Python is correctly associated).
   - Option B: Open Command Prompt in the folder and type:Technical Requirements: 
1. Use Python to open and read from the dictionary file. 
2. Take a word as input from the user. 
3. Search that word in the dictionary (case-insensitive). 
4. If found: 
o Show its Urdu meaning on the screen. 
o Speak the English word (using gTTS with lang='en'). 
o Speak the Urdu meaning (using gTTS with lang='ur'). 
5. If not found, show a friendly message. 
�
� Features: 
 Add error handling (e.g., if file not found, or internet not available). 
 Let the user keep searching until they type exit 

     ```
     python dictionary_app.py
     ```

### Step 3: Using the App
- **Search**: Type a word in the top input box and click "Search" to see the meaning.
- **Add New Word**:
  - Fill in a new word and its meaning.
  - Click "Add Word" to save it permanently to the dictionary.

## 📄 dictionary.txt Format
Each line contains a word and its meaning, separated by a colon:
